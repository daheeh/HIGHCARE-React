// import { Link, Route, Router, Routes } from "react-router-dom";
// import PmTest from "./pm-test";
// import PmMenu from "../pm/search";
// import PmAnnual from "./annual";
// import PmCalender from "./cal";
// import PmResist from "./de-resist";
// import PmDepartment from "./department";
// import PmMemberAnnual from "./member-annual";
// import PmMemberResist from "./pm-resist";
// import PmWork from "./work";

// function PmManage(){

//     return (

//         <div>

//             <Routes>
//                 <Route path="/" element={<PmTest />}/>
//                 <Route path="/pm/search" element={<PmMenu />}/>
//                 <Route path="/pm/annual" element={<PmAnnual />}/>
//                 <Route path="/pm/cal" element={<PmCalender />}/>
//                 <Route path="/pm/de-resist" element={<PmResist />}/>
//                 <Route path="/pm/department" element={<PmDepartment />}/>
//                 <Route path="/pm/member-annual" element={<PmMemberAnnual />}/>
//                 <Route path="/pm/pm-resist" element={<PmMemberResist />}/>
//                 <Route path="/pm/work" element={<PmWork />}/>
//             </Routes>
//         </div>

//     )
// }

// export default PmManage;