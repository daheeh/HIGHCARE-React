import './ReservationNavStyle.css'

function ReservationNav(){
    return (
            <div class="leftmenu">
	
		    <div class="leftmenu2">
	
			<div class="maintitle">
				예약
			</div>
			<div class="apv_navibox">
				<div class="apv_navibox_maintitle">자원예약</div>
				<div class="apv_navibox_emp"></div>
				<div class="apv_navibox_maintitle">자원추가</div>
				<div class="apv_navibox_emp"></div>
				<div class="apv_navibox_maintitle">나의 신청현황</div>
				<div class="apv_navibox_emp"></div>
				<div class="apv_navibox_maintitle">신청현황</div>
				
			</div>
		</div>
	</div>
    )
}

export default ReservationNav;