import { BASE_URL } from "../../utils/urlConstants.tsx"

const SocialButton = ({socialNetwork}) => {
    
    return (

        <a href={`${BASE_URL}/login/outh2/code/${socialNetwork}`}>
            <button>
                {`Login with ${socialNetwork.charAt(0).toUpperCase()
                }`}
            </button>
        </a>
    )
}

export default SocialButton;