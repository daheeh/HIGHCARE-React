import Logininfo from './logininfo';
import SocialLogin from './social-login';
import React from 'react';

function Login() {


  return (

    <div>
      <div className="" >
        <Logininfo />
      </div>
      <div className="">
        <SocialLogin />
      </div>
    </div>

  );
}


export default Login;