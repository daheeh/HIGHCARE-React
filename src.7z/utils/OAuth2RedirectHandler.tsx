import React, {FC} from "react"
import { ACCOUNT } from "./urlConstants";
import { redirect } from "react-router-dom";

const OAuth2RedirectHandler: FC = () => {
    const url: Location = window.location; 
    const token: string | null = new URLSearchParams(url.search).get("accessToken");

    if(token){
        localStorage.setItem("accessToken", token);
    } 
    return <Redirect to={ACCOUNT} />;
}

export default OAuth2RedirectHandler;