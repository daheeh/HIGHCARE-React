import axios, { Method } from "axios";
import { API_BASE_URL } from "./urlConstants";
import React from "react";

class RequestService {
    get = (url: string, isAuthRequired: boolean = false, contentType: string = "application/json") => {
        return createRequest("GET", url, null, isAuthRequired, contentType);
    };

    post = (url: string, body: any, isAuthRequired: boolean = false, contentType: string = "application/json") => {
        return createRequest("POST", url, body, isAuthRequired, contentType);
    };
    

    put = (url: string, body: any, isAuthRequired: boolean = false, contentType: string = "application/json") => {
        return createRequest("PUT", url, body, isAuthRequired, contentType);
    };

    delete = (url: string, isAuthRequired: boolean = false, contentType: string = "application/json") => {
        return createRequest("DELETE", url, null, isAuthRequired, contentType);
    };
}

const createRequest = (method: Method, url: string, body: any, isAuthRequired: boolean, contentType: string) => {
    setHeader(isAuthRequired, contentType)
    return axios({
        url: API_BASE_URL + url, 
        method: method, 
        data: body, 
    });
}

const setHeader = ( isAuthRequired: boolean, contentType: string) => {
    if(isAuthRequired){
        axios.defaults.headers.common["Authorization"] = localStorage.getItem("accessToken"); 
    } else{
        delete axios.defaults.headers.common["Authorization"];
    }
    axios.defaults.headers.common["Content-Type"] = contentType;
};

export default new RequestService();
