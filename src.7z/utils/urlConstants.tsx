//  base url 설정해두기 

export const BASE_URL = "http://localhost:8080";
export const API_BASE_URL = BASE_URL + "/api";
// export const WEBSOCKET_URL = BASE_URL + "/websocket";


export const ADMIN = "/admin"

// auth
export const AUTH_LOGIN = "/auth/login";
export const AUTH_FORGOT = "/auth/forgot"
export const AUTH_RESET = "/auth/reset"
export const AUTH_REISSUE = "/auth/reissue"
export const AUTH_EDIT_PASSWORD = "/auth/edit/password"

// admin
export const ADMIN_GET_MEMBER = "/admin/member"
export const ADMIN_JOIN_MEMBER = "/admin/member/join"

export const ACCOUNT = "/account";

export const BASE = "/";
export const LOGIN = "/login";
export const REGISTRATION = "/registration";
export const FORGOT = "/forgot";
export const RESET = "/reset";